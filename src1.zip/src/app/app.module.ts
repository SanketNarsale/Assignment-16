import { NgModule } from '@angular/core';
import { BrowserModule, provideClientHydration } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MyAddPipe } from './my-add.pipe';
import { MyMultPipe } from './my-mult.pipe';


@NgModule({
  declarations: [
    AppComponent,
    MyAddPipe,
    MyMultPipe
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MyAddPipe,
    MyMultPipe
  ],
  providers: [
    provideClientHydration()
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
