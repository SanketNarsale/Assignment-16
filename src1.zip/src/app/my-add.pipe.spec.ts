import { MyAddPipe } from './my-add.pipe';

describe('MyAddPipe', () => {
  let pipe: MyAddPipe;

  beforeEach(() => {
    pipe = new MyAddPipe();
  });

  it('should create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('should add the two numbers', () => {
    const number1 = 10;
    const number2 = 20;

    const result = pipe.transform(number1, number2);

    expect(result).toBe(number1 + number2);
  });
});