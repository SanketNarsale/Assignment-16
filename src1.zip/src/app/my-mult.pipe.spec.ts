import { MyMultPipe } from './my-mult.pipe';
describe('MyMultPipe', () => {
  let pipe: MyMultPipe;

  beforeEach(() => {
    pipe = new MyMultPipe();
  });

  it('should create an instance', () => {
    expect(pipe).toBeTruthy();
  });

  it('should add the two numbers', () => {
    const number1 = 10;
    const number2 = 20;

    const result = pipe.transform(number1, number2);

    expect(result).toBe(number1 * number2);
  });
});
