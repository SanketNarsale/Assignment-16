import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // Method to count the number of capital letters in a string
  countCapital(str: string): number {
    return str.replace(/[^A-Z]/g, "").length;
  }

  // Method to check password strength
  checkPassword(password: string): boolean {
    // Check if password contains at least 2 capital letters
    if (this.countCapital(password) < 2) {
      return false;
    }

    // Check if password contains at least 3 small letters
    if (password.replace(/[^a-z]/g, "").length < 3) {
      return false;
    }

    // Check if password contains at least 2 digits
    if (password.replace(/[^0-9]/g, "").length < 2) {
      return false;
    }

    // Check if password contains at least 1 special symbol
    if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]+/.test(password)) {
      return false;
    }

    // Password meets all criteria
    return true;
}

  // Method to add elements of an array
  arrayAddition(arr: number[]): number {
    return arr.reduce((sum, num) => sum + num, 0);
  }
}
