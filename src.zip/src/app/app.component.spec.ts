import { TestBed } from '@angular/core/testing';
import { RouterTestingModule } from '@angular/router/testing';
import { AppComponent } from './app.component';

describe('AppComponent', () => {
  let component: AppComponent;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [RouterTestingModule],
      declarations: [AppComponent],
    }).compileComponents();

    // Create the component instance
    component = new AppComponent();
  });


  it('should create the app', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app).toBeTruthy();
  });

  it('should count capital letters correctly', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.countCapital('Hello World')).toEqual(2);
    expect(app.countCapital('Testing123')).toEqual(1);
    expect(app.countCapital('abc')).toEqual(0);
  });

  
  it('should add array elements correctly', () => {
    const fixture = TestBed.createComponent(AppComponent);
    const app = fixture.componentInstance;
    expect(app.arrayAddition([1, 2, 3, 4])).toEqual(10);
    expect(app.arrayAddition([10, -5, 3])).toEqual(8);
    expect(app.arrayAddition([])).toEqual(0);
  });
});
